#include <iostream>
#include <string>
using namespace std ;
class stud {
    private :
    int id ;
    string FN;
    string LN;
    float grade;
    public:
    stud(int id,string FN, string LN, float grade) :
    id(id) , FN(FN) , LN(LN) ,grade(grade) {} ;
    float getGrade() {
        return grade;}
};
class trch {
    private :
    int id ;
    string FN;
    string LN;
    float salery;
    public:
    trch(int id,string FN, string LN, int salery) :
    id(id) , FN(FN) , LN(LN) ,salery(salery) {} ;
    int getSalery() {
        return salery;}
};
int main(){
    stud student1(12 , "faramarz" , "rahimi", 19.3);
    stud student2(13 , "faraz" , "rahimian", 7);
    stud student3(14 , "farzad" , "rahmati", 15.45);
    trch teacher1(101 , "behdad", "panah" , 260000);
    trch teacher2(102 , "behtash", "panahian" , 2);
    trch teacher3(103 , "behrad", "panahi" , 10000000);
    cout<<"grade :" << student1.getGrade() <<endl;
    cout<< "grade :"<< student2.getGrade() <<endl;
    cout<< "grade :"<< student3.getGrade() <<endl;
    cout<<"-----------------------"<<endl;
    cout<< "salery :"<< teacher1.getSalery()<< " $"<<endl;
    cout<< "salery :"<< teacher2.getSalery()<< " $"<<endl;
    cout<< "salery :"<< teacher3.getSalery()<< " $"<<endl;
}